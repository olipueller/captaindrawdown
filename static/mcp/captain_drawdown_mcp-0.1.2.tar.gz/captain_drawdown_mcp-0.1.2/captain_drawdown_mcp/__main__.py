"""`python -m captain_drawdown_mcp` starts the stdio server."""
from .server import main

main()
