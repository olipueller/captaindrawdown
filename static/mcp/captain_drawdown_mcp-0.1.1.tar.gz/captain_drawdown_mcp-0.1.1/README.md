# captain-drawdown-mcp

An MCP server that gives Claude, ChatGPT, Cursor and other MCP clients direct access to Captain Drawdown's open data on carbon dioxide removal (CDR):

- **Companies**: 969 published CDR companies with pathway, country, liveliness tier, EU SME size class, registries and evidence dates (CC BY-NC-SA 4.0).
- **Researchers**: 95,000+ researchers with CDR papers since 2021, aggregated by country and pathway, plus top-100 lists per pathway (CC BY 4.0).
- **Shops**: shops where individuals buy certified removal, with prices (CC BY 4.0).

It reads the public static API at `https://captaindrawdown.com/api/v1/` (no key, CORS open) and caches responses for six hours. Every result carries `version`, `as_of`, `license` and `cite_as`.

## Install

```bash
pip install captain-drawdown-mcp      # or: uvx captain-drawdown-mcp
```

Claude Desktop / Claude Code (`claude mcp add captain-drawdown -- captain-drawdown-mcp`) or `claude_desktop_config.json`:

```json
{"mcpServers": {"captain-drawdown": {"command": "captain-drawdown-mcp"}}}
```

Cursor (`.cursor/mcp.json`): same `command`. Any client that speaks MCP over stdio works.

## Tools

| Tool | What it returns |
|---|---|
| `stats()` | headline numbers of the newest release |
| `search_companies(query, country_code, pathway, size_class, region, limit)` | matching companies with slugs |
| `company(slug)` | one company |
| `countries()`, `pathways()` | companies per country / per pathway |
| `researchers_by_country()`, `researchers_by_pathway()` | listed researchers with the calibrated estimate |
| `top_researchers(pathway, region, limit, ranking)` | top 100 worldwide or top 50 in Europe for a pathway; ranking `active` (CDR papers since 2021 weighted by age, half-life three years) or `cited` (citations to those papers) |
| `shops()` | shops with prices |
| `cite()` | citation and licences |

## Data and licences

Pages: https://captaindrawdown.com/data/ · API: https://captaindrawdown.com/api/ · Corrections: info@carbon-drawdown.de. The server code is MIT; the data keeps its own licences (companies CC BY-NC-SA 4.0 because the directory is seeded from Grant Faber's list; researchers and shops CC BY 4.0).

Captain Drawdown is a project of the Carbon Drawdown Initiative (Fürth, Germany).
