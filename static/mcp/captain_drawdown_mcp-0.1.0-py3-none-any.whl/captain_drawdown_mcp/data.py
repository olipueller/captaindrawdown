"""Data access for the Captain Drawdown MCP server: reads the static JSON API
(https://captaindrawdown.com/api/v1/) and filters in memory. No mcp import
here so the logic is testable without the SDK."""
import json
import time
from typing import Callable, Optional
from urllib.request import Request, urlopen

API_BASE = "https://captaindrawdown.com/api/v1"
CACHE_TTL_S = 6 * 3600


def _http_get(url: str) -> dict:
    req = Request(url, headers={"User-Agent": "captain-drawdown-mcp/0.1 (+https://captaindrawdown.com/api/)"})
    with urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


class Api:
    """Small cached client. `fetch` is injectable for tests."""

    def __init__(self, base: str = API_BASE, fetch: Optional[Callable[[str], dict]] = None,
                 ttl_s: int = CACHE_TTL_S):
        self.base = base.rstrip("/")
        self.fetch = fetch or _http_get
        self.ttl = ttl_s
        self._cache = {}

    def get(self, path: str) -> dict:
        now = time.time()
        hit = self._cache.get(path)
        if hit and now - hit[0] < self.ttl:
            return hit[1]
        data = self.fetch(f"{self.base}/{path.lstrip('/')}")
        self._cache[path] = (now, data)
        return data

    # ── tools ──────────────────────────────────────────────────────────
    def stats(self) -> dict:
        return self.get("stats.json")

    def company(self, slug: str) -> dict:
        slug = (slug or "").strip().lower()
        if not slug:
            return {"error": "slug required"}
        try:
            return self.get(f"companies/{slug}.json")
        except Exception:
            return {"error": f"unknown slug {slug!r}; use search_companies to find the slug"}

    def search_companies(self, query: str = "", country_code: str = "", pathway: str = "",
                         size_class: str = "", region: str = "", limit: int = 25) -> dict:
        env = self.get("companies.json")
        rows = env.get("data", [])
        q = (query or "").strip().lower()
        cc = (country_code or "").strip().upper()
        pw = (pathway or "").strip().lower()
        sc = (size_class or "").strip().lower()
        rg = (region or "").strip().lower()
        out = []
        for c in rows:
            if q and q not in f"{c.get('name', '')} {c.get('description', '')} {c.get('pathway_primary', '')}".lower():
                continue
            if cc and (c.get("country_code") or "").upper() != cc:
                continue
            if pw and pw not in (c.get("pathway_primary") or "").lower():
                continue
            if sc and sc not in (c.get("size_class") or "").lower():
                continue
            if rg and rg not in (c.get("region") or "").lower():
                continue
            out.append({k: c.get(k) for k in ("name", "slug", "country", "country_code", "region",
                                               "pathway_primary", "liveliness_tier", "size_class",
                                               "url", "profile_url")})
        limit = max(1, min(int(limit or 25), 200))
        return {"version": env.get("version"), "as_of": env.get("as_of"), "license": env.get("license"),
                "cite_as": env.get("cite_as"), "matches": len(out), "data": out[:limit]}

    def countries(self) -> dict:
        return self.get("countries.json")

    def pathways(self) -> dict:
        return self.get("pathways.json")

    def researchers_by_country(self) -> dict:
        return self.get("researchers/by-country.json")

    def researchers_by_pathway(self) -> dict:
        return self.get("researchers/by-pathway.json")

    def top_researchers(self, pathway: str, region: str = "global", limit: int = 25) -> dict:
        slug = (pathway or "").strip().lower().replace(" ", "-")
        try:
            env = self.get(f"researchers/top/{slug}.json")
        except Exception:
            idx = self.get("index.json")
            return {"error": f"unknown pathway {pathway!r}", "pathways": idx.get("pathway_slugs", [])}
        key = "europe_top50" if (region or "").lower().startswith("eu") else "global_top100"
        rows = env.get("data", {}).get(key, [])
        limit = max(1, min(int(limit or 25), 100))
        return {"version": env.get("version"), "as_of": env.get("as_of"), "license": env.get("license"),
                "cite_as": env.get("cite_as"), "pathway": env.get("data", {}).get("pathway"),
                "ranking": key, "data": rows[:limit]}

    def shops(self) -> dict:
        return self.get("shops.json")

    def cite(self) -> dict:
        idx = self.get("index.json")
        return {"version": idx.get("version"), "as_of": idx.get("as_of"), "cite_as": idx.get("cite_as"),
                "licenses": idx.get("licenses"), "data_pages": idx.get("data_pages")}
