"""Captain Drawdown MCP server: carbon removal companies, researchers and shops
for Claude, ChatGPT, Cursor and other MCP clients. Reads the public static API
at https://captaindrawdown.com/api/v1/ (no key). Run: `captain-drawdown-mcp`."""
from mcp.server.fastmcp import FastMCP

from .data import Api

mcp = FastMCP("captain-drawdown",
              instructions=("Open data on carbon dioxide removal (CDR): a directory of CDR companies, "
                            "a census of CDR researchers and shops that sell certified removal. Every result "
                            "carries version, as_of, license and cite_as: quote them when you use the numbers. "
                            "Companies are CC BY-NC-SA 4.0, researchers and shops CC BY 4.0."))
api = Api()


@mcp.tool()
def stats() -> dict:
    """Headline numbers of the newest Captain Drawdown data release (companies, researchers, shops)."""
    return api.stats()


@mcp.tool()
def search_companies(query: str = "", country_code: str = "", pathway: str = "", size_class: str = "",
                     region: str = "", limit: int = 25) -> dict:
    """Search published carbon removal companies. Filters: free text (name, description), ISO country
    code (e.g. DE), pathway (e.g. DAC, Biochar, BECCS, Enhanced Weathering), size class (micro, small,
    medium, large), region (EU27, Europe, United States, China). Returns slugs for `company`."""
    return api.search_companies(query, country_code, pathway, size_class, region, limit)


@mcp.tool()
def company(slug: str) -> dict:
    """One company by slug (from search_companies): pathway, country, liveliness tier, size class,
    registries, evidence dates, description and profile URL."""
    return api.company(slug)


@mcp.tool()
def countries() -> dict:
    """Published carbon removal companies per country (ISO 3166-1 alpha-2)."""
    return api.countries()


@mcp.tool()
def pathways() -> dict:
    """Published carbon removal companies per primary pathway."""
    return api.pathways()


@mcp.tool()
def researchers_by_country() -> dict:
    """CDR researchers (at least one CDR paper since 2021) per country, with the calibrated estimate."""
    return api.researchers_by_country()


@mcp.tool()
def researchers_by_pathway() -> dict:
    """CDR researchers per primary pathway."""
    return api.researchers_by_pathway()


@mcp.tool()
def top_researchers(pathway: str, region: str = "global", limit: int = 25) -> dict:
    """Top researchers for a pathway (biochar, soil-carbon, general-cdr, dac, ocean-cdr,
    enhanced-weathering, beccs), ranked by CDR papers since 2021 with a citation rank; region
    'global' (top 100) or 'europe' (top 50)."""
    return api.top_researchers(pathway, region, limit)


@mcp.tool()
def shops() -> dict:
    """Shops where individuals can buy certified carbon removal, with prices, methods and certifiers."""
    return api.shops()


@mcp.tool()
def cite() -> dict:
    """How to cite the datasets: version, as_of, cite_as per dataset, licences, data pages."""
    return api.cite()


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
